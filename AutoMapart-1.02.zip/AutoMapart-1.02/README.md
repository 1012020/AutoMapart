See `src/main/java/me/bebeli555/automapart/mods/world/AutoMapart.java`

1. Add the name of the NBT schematic in the config
2. Position the schematic to the mapart machine (Use RenderBlocks to see it)
3. Have free inventory space (in hotbar too)
4. Start the module and it will build the mapart
