package me.bebeli555.automapart.events.game;

public class GetFovEvent {
    public double fov;

    public GetFovEvent(double fov) {
        this.fov = fov;
    }
}
