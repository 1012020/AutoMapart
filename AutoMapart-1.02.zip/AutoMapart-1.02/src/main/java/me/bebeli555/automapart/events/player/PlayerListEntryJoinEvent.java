package me.bebeli555.automapart.events.player;

import net.minecraft.client.network.PlayerListEntry;

public record PlayerListEntryJoinEvent(PlayerListEntry entry) {}
