package me.bebeli555.automapart.events.player;

public class PlayerAllowFlyingEvent {
    public boolean allowFlying;

    public PlayerAllowFlyingEvent(boolean allowFlying) {
        this.allowFlying = allowFlying;
    }
}
