package me.bebeli555.automapart.utils.objects;

public enum Phase {
    PRE,
    POST
}
