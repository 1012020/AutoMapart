package me.bebeli555.automapart.events.game;

public class TimerEvent {
    public boolean onlyMovement;
    public double tps = 20;
}
