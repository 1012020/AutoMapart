package me.bebeli555.automapart.events.player;

import me.bebeli555.automapart.events.Cancellable;

public class PlayerMotionUpdateEvent extends Cancellable {

}