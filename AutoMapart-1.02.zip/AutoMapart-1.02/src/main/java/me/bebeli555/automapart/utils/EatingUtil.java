package me.bebeli555.automapart.utils;

import me.bebeli555.automapart.Mod;

//TODO
public class EatingUtil extends Mod {

}
