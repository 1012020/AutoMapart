package me.bebeli555.automapart.events.entity;

public class PlayerTravelEvent {
}
