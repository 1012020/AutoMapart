package me.bebeli555.automapart.events.game;

public class ClientTickPostEvent {
}
