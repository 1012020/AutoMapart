package me.bebeli555.automapart.events.game;

public class ClientTickEvent {
    public static class Playing {

    }
}
