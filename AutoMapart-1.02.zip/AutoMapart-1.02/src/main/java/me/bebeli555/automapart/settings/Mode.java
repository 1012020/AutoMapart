package me.bebeli555.automapart.settings;

public enum Mode {
	BOOLEAN,
	INTEGER,
	DOUBLE,
	TEXT,
	LABEL,
	COLOR,
	PICKER,
	KEYBIND,
	TEXT_ARRAY
}
