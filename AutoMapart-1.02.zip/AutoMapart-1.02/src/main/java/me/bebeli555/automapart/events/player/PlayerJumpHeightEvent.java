package me.bebeli555.automapart.events.player;

public class PlayerJumpHeightEvent {
    public float height;

    public PlayerJumpHeightEvent(float height) {
        this.height = height;
    }
}
