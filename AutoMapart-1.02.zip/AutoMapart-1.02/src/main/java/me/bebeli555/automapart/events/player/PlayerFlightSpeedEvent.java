package me.bebeli555.automapart.events.player;

public class PlayerFlightSpeedEvent {
    public float speed;

    public PlayerFlightSpeedEvent(float speed) {
        this.speed = speed;
    }
}
