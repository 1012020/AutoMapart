package me.bebeli555.automapart.events.game;

import me.bebeli555.automapart.events.Cancellable;

public class ChatScreenKeyEvent extends Cancellable {

}
