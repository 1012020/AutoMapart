package me.bebeli555.automapart.utils;

//TODO
public class MiningUtils extends Utils {

}
