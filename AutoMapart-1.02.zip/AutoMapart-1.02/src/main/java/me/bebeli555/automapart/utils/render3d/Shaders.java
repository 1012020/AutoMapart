package me.bebeli555.automapart.utils.render3d;

public class Shaders {
    public static Shader POS_COLOR = new Shader("pos_color.vert", "pos_color.frag");
}
