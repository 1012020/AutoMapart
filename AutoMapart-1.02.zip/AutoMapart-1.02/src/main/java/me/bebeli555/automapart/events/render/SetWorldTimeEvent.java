package me.bebeli555.automapart.events.render;

import me.bebeli555.automapart.events.Cancellable;

public class SetWorldTimeEvent extends Cancellable {
}
