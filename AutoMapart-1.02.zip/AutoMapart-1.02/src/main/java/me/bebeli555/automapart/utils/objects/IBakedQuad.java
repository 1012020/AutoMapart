package me.bebeli555.automapart.utils.objects;

public interface IBakedQuad {
    float sierra$getX(int vertexI);
    float sierra$getY(int vertexI);
    float sierra$getZ(int vertexI);
}
