package me.bebeli555.automapart.events.game;

public class GetMouseSensitivityEvent {
    public double value;

    public GetMouseSensitivityEvent(double value) {
        this.value = value;
    }
}
